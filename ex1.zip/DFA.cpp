//
// Created by Pim Van den Bosch on 2023/03/06.
//

#include "DFA.h"

DFA::DFA() {
    accepting_states_ = {0};
    start_state_ = 0;
    transitions_ = {
            //   0  1
            {0, 1}, // 0
            {2, 0}, // 1
            {1, 2}, // 2
    };
}

bool DFA::accepts(const std::string& input) {
    int current_state = start_state_;
    for (char c : input) {
        int input_symbol = c - '0';
        current_state = transitions_[current_state][input_symbol];
    }
    return accepting_states_.count(current_state) > 0;
}
