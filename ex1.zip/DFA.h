//
// Created by Pim Van den Bosch on 2023/03/06.
//

#ifndef CODE_DFA_H
#define CODE_DFA_H

#include <unordered_set>
#include <vector>
#include <string>

class DFA {
public:
    DFA();
    bool accepts(const std::string& input);

private:
    std::unordered_set<int> accepting_states_;
    std::vector<std::vector<int>> transitions_;
    int start_state_;
};

#endif //CODE_DFA_H
